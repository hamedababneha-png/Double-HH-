import { Router, type IRouter } from "express";
import {
  AddCartItemBody,
  ApplyCouponBody,
  ApplyCouponResponse,
  ConfirmDeliveryBody,
  ConfirmDeliveryParams,
  ConfirmDeliveryResponse,
  CreateOrderBody,
  CreateProductBody,
  DeliveryOtpResponse,
  GetOrderTrackingParams,
  GetOrderTrackingResponse,
  GetCartResponse,
  GetCustomerProfileResponse,
  GetProductParams,
  GetProductResponse,
  GetReportSummaryResponse,
  GetSessionResponse,
  ListCategoriesResponse,
  ListProductsQueryParams,
  ListProductsResponse,
  ListOrdersResponse,
  RemoveCartItemParams,
  RequestDeliveryOtpParams,
  RequestDeliveryOtpResponse,
  CreateCustomerAddressBody,
  CreateCustomerAddressResponse,
  UpdateProductBody,
  UpdateProductParams,
} from "@workspace/api-zod";

type Product = {
  id: number;
  title: string;
  description: string;
  price: number;
  compareAtPrice: number | null;
  discountPercent?: number;
  category: string;
  brand: string;
  imageUrl: string;
  sellerName: string;
  rating: number;
  reviewCount: number;
  stock: number;
  source: "double_hh" | "shein" | "amazon" | "temu" | "alibaba";
  sellerProfitPercent?: number;
  isFeatured?: boolean;
};

type CartLine = {
  product: Product;
  quantity: number;
  lineTotal: number;
};

type Order = {
  id: string;
  status:
    | "pending_payment"
    | "paid"
    | "preparing"
    | "shipping"
    | "delivered"
    | "cancelled";
  createdAt: string;
  total: number;
  paymentMethod: "visa" | "click" | "ewallet" | "paypal" | "cash_on_delivery";
  itemCount: number;
};

const ADMIN_COMMISSION_RATE = 0.03;

const products: Product[] = [
  {
    id: 1,
    title: "سماعات عزل ضجيج لاسلكية",
    description: "سماعات مريحة بصوت واضح وبطارية تدوم طوال اليوم.",
    price: 39.9,
    compareAtPrice: 59.9,
    discountPercent: 33,
    category: "إلكترونيات",
    brand: "Soundcore",
    imageUrl:
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=85",
    sellerName: "متجر التقنية",
    rating: 4.8,
    reviewCount: 128,
    stock: 24,
    source: "double_hh",
    sellerProfitPercent: 12,
    isFeatured: true,
  },
  {
    id: 2,
    title: "حقيبة جلدية يومية",
    description: "حقيبة عملية من الجلد الصناعي بتقسيمات ذكية للعمل والسفر.",
    price: 28.5,
    compareAtPrice: 36,
    discountPercent: 21,
    category: "أزياء",
    brand: "Luna",
    imageUrl:
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=85",
    sellerName: "دار الأناقة",
    rating: 4.6,
    reviewCount: 76,
    stock: 17,
    source: "shein",
    sellerProfitPercent: 18,
    isFeatured: true,
  },
  {
    id: 3,
    title: "مصباح مكتب ذكي",
    description: "إضاءة قابلة للتعديل مع شحن لاسلكي وتصميم هادئ.",
    price: 24,
    compareAtPrice: null,
    category: "المنزل",
    brand: "Noma",
    imageUrl:
      "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=85",
    sellerName: "بيت عصري",
    rating: 4.7,
    reviewCount: 43,
    stock: 31,
    source: "temu",
    sellerProfitPercent: 15,
    isFeatured: true,
  },
  {
    id: 4,
    title: "ساعة رياضية مقاومة للماء",
    description: "تتبع النشاط والنوم مع شاشة واضحة وسوار مريح.",
    price: 44.75,
    compareAtPrice: 52,
    discountPercent: 14,
    category: "رياضة",
    brand: "Amazfit",
    imageUrl:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=85",
    sellerName: "زون سبورت",
    rating: 4.5,
    reviewCount: 91,
    stock: 12,
    source: "amazon",
    sellerProfitPercent: 10,
    isFeatured: false,
  },
  {
    id: 5,
    title: "طقم عناية بالبشرة",
    description: "روتين يومي لطيف للبشرة الجافة والحساسة.",
    price: 19.95,
    compareAtPrice: 26,
    discountPercent: 23,
    category: "جمال",
    brand: "Pure Lab",
    imageUrl:
      "https://images.unsplash.com/photo-1556228578-8c89e6adf883?auto=format&fit=crop&w=900&q=85",
    sellerName: "عناية بلس",
    rating: 4.9,
    reviewCount: 152,
    stock: 44,
    source: "alibaba",
    sellerProfitPercent: 20,
    isFeatured: false,
  },
  {
    id: 6,
    title: "حذاء يومي خفيف",
    description: "راحة في المشي اليومي مع نعل مرن ومظهر بسيط.",
    price: 32,
    compareAtPrice: 40,
    discountPercent: 20,
    category: "أزياء",
    brand: "Step",
    imageUrl:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85",
    sellerName: "دار الأناقة",
    rating: 4.4,
    reviewCount: 68,
    stock: 20,
    source: "shein",
    sellerProfitPercent: 16,
    isFeatured: false,
  },
];

const categories = [
  { id: 1, name: "إلكترونيات", productCount: 18 },
  { id: 2, name: "أزياء", productCount: 24 },
  { id: 3, name: "المنزل", productCount: 12 },
  { id: 4, name: "رياضة", productCount: 9 },
  { id: 5, name: "جمال", productCount: 15 },
];

const cart: Map<number, number> = new Map([
  [2, 1],
]);
let appliedCoupon: string | null = null;
const customerAddresses = [
  { id: 1, label: "البيت", address: "عمّان، الشميساني، شارع عبد الحميد شرف، بناية 18", isDefault: true },
  { id: 2, label: "العمل", address: "عمّان، العبدلي، بوليفارد العبدلي، مكتب 402", isDefault: false },
];
let loyaltyPoints = 860;
let walletBalance = 6.75;

const orders: Order[] = [
  {
    id: "HH-2048",
    status: "shipping",
    createdAt: "2026-09-21T10:30:00.000Z",
    total: 57,
    paymentMethod: "click",
    itemCount: 2,
  },
  {
    id: "HH-2031",
    status: "delivered",
    createdAt: "2026-09-17T14:15:00.000Z",
    total: 39.9,
    paymentMethod: "visa",
    itemCount: 1,
  },
];

type DeliveryMeta = {
  address: string;
  deliveryPartnerId: number | null;
  deliveryPartnerName: string;
  otp: string;
  otpExpiresAt: number;
  trackingStartedAt: number;
  sellerCount: number;
  packageCount: number;
  savedShipping: number;
  otpVerified: boolean;
};

const deliveryMeta = new Map<string, DeliveryMeta>([
  [
    "HH-2048",
    {
      address: "عمّان، الشميساني، شارع عبد الحميد شرف، بناية 18",
      deliveryPartnerId: 1,
      deliveryPartnerName: "Aramex Jordan",
      otp: "482913",
      otpExpiresAt: Date.now() + 8 * 60 * 1000,
      trackingStartedAt: Date.now() - 4 * 60 * 1000,
      sellerCount: 2,
      packageCount: 1,
      savedShipping: 2.5,
      otpVerified: false,
    },
  ],
  [
    "HH-2031",
    {
      address: "عمّان، خلدا، شارع وصفي التل",
      deliveryPartnerId: 2,
      deliveryPartnerName: "Jeeny Delivery",
      otp: "371604",
      otpExpiresAt: Date.now() - 24 * 60 * 60 * 1000,
      trackingStartedAt: Date.now() - 7 * 24 * 60 * 60 * 1000,
      sellerCount: 1,
      packageCount: 1,
      savedShipping: 0,
      otpVerified: true,
    },
  ],
]);

const deliveryPartners: Record<number, { name: string; phone: string; vehicle: string }> = {
  1: { name: "محمد العياصرة", phone: "+962 7 9012 3488", vehicle: "فان أبيض · 42-ج-118" },
  2: { name: "ليث الخطيب", phone: "+962 7 8871 2041", vehicle: "دراجة · 18-م-902" },
  3: { name: "سامي الزعبي", phone: "+962 7 7710 6652", vehicle: "سيارة · 33-ع-741" },
};

function newDeliveryMeta(input: {
  address: string;
  deliveryPartnerId: number | null;
  sellerCount: number;
}) {
  const partner = deliveryPartners[input.deliveryPartnerId ?? 1] ?? deliveryPartners[1];
  return {
    address: input.address,
    deliveryPartnerId: input.deliveryPartnerId,
    deliveryPartnerName: partner.name,
    otp: String(Math.floor(100000 + Math.random() * 900000)),
    otpExpiresAt: Date.now() + 8 * 60 * 1000,
    trackingStartedAt: Date.now(),
    sellerCount: input.sellerCount,
    packageCount: 1,
    savedShipping: input.sellerCount > 1 ? 2.5 : 0,
    otpVerified: false,
  } satisfies DeliveryMeta;
}

function getDeliveryMeta(order: Order) {
  const existing = deliveryMeta.get(order.id);
  if (existing) return existing;
  const created = newDeliveryMeta({
    address: "عمّان، الأردن",
    deliveryPartnerId: 1,
    sellerCount: 1,
  });
  deliveryMeta.set(order.id, created);
  return created;
}

function buildTracking(order: Order) {
  const meta = getDeliveryMeta(order);
  const elapsed = Math.max(0, Date.now() - meta.trackingStartedAt);
  const progress =
    order.status === "delivered"
      ? 1
      : order.status === "shipping"
        ? Math.min(0.94, 0.18 + elapsed / (15 * 60 * 1000) * 0.72)
        : 0;
  const start = { latitude: 31.9638, longitude: 35.8898 };
  const destination = { latitude: 31.9845, longitude: 35.8972 };
  const courier = deliveryPartners[meta.deliveryPartnerId ?? 1] ?? deliveryPartners[1];
  const statusIndex = {
    pending_payment: 0,
    paid: 1,
    preparing: 1,
    shipping: 2,
    delivered: 3,
    cancelled: -1,
  }[order.status];
  const timelineStatuses = [
    {
      status: "paid",
      label: "تم تأكيد الطلب",
      description: "تم استلام الدفع وتجهيز الطلب للمتابعة.",
      at: order.createdAt,
    },
    {
      status: "preparing",
      label: "قيد التجهيز",
      description: "تم جمع المنتجات من البائعين في طرد واحد.",
      at: new Date(new Date(order.createdAt).getTime() + 20 * 60 * 1000).toISOString(),
    },
    {
      status: "shipping",
      label: "في الطريق إليك",
      description: `مندوب ${meta.deliveryPartnerName} يتحرك نحو عنوانك.`,
      at: new Date(new Date(order.createdAt).getTime() + 50 * 60 * 1000).toISOString(),
    },
    {
      status: "delivered",
      label: "تم التسليم الآمن",
      description: "لا يكتمل التسليم إلا بعد مطابقة رمز الاستلام.",
      at: meta.otpVerified ? new Date().toISOString() : null,
    },
  ];

  return {
    order,
    timeline: timelineStatuses.map((item, index) => ({
      ...item,
      completed: index <= statusIndex,
    })),
    courier: {
      id: meta.deliveryPartnerId ?? 1,
      name: courier.name,
      phone: courier.phone,
      vehicle: courier.vehicle,
      latitude: Number((start.latitude + (destination.latitude - start.latitude) * progress).toFixed(6)),
      longitude: Number((start.longitude + (destination.longitude - start.longitude) * progress).toFixed(6)),
      updatedAt: new Date().toISOString(),
    },
    shipment: {
      shipmentId: `SHIP-${order.id}`,
      sellerCount: meta.sellerCount,
      packageCount: meta.packageCount,
      combined: meta.sellerCount > 1,
      savedShipping: meta.savedShipping,
    },
    deliveryCodeHint: meta.otpVerified
      ? "تم استخدام رمز الاستلام"
      : `ينتهي بـ ${meta.otp.slice(-2)}`,
    codeExpiresAt: new Date(meta.otpExpiresAt).toISOString(),
    canConfirm: ["preparing", "shipping"].includes(order.status) && !meta.otpVerified,
    progress: Number(progress.toFixed(3)),
  };
}

function calculateCart() {
  const items: CartLine[] = Array.from(cart.entries())
    .map(([productId, quantity]) => {
      const product = products.find((item) => item.id === productId);
      if (!product) return null;
      return {
        product,
        quantity,
        lineTotal: Number((product.price * quantity).toFixed(2)),
      };
    })
    .filter((item): item is CartLine => item !== null);

  const subtotal = Number(
    items.reduce((sum, item) => sum + item.lineTotal, 0).toFixed(2),
  );
  const adminCommission = Number(
    (subtotal * ADMIN_COMMISSION_RATE).toFixed(2),
  );
  const couponDiscount =
    appliedCoupon === "HH10"
      ? Math.min(10, subtotal * 0.1)
      : appliedCoupon === "WELCOME"
        ? Math.min(5, subtotal * 0.05)
        : 0;
  const shippingFee = appliedCoupon === "FREESHIP" ? 0 : items.length ? 2.5 : 0;
  const discount = Number(couponDiscount.toFixed(2));
  const total = Number(Math.max(0, subtotal - discount + shippingFee).toFixed(2));

  return {
    items,
    subtotal,
    adminCommission,
    discount,
    couponCode: appliedCoupon,
    shippingFee,
    total,
    loyaltyPointsEarned: Math.floor(total),
  };
}

function makeProduct(input: {
  id: number;
  title: string;
  description: string;
  price: number;
  compareAtPrice?: number | null;
  category: string;
  brand: string;
  imageUrl: string;
  stock: number;
  source?: Product["source"];
  sellerProfitPercent?: number;
}): Product {
  const compareAtPrice = input.compareAtPrice ?? null;
  return {
    ...input,
    compareAtPrice,
    source: input.source ?? "double_hh",
    sellerName: "متجر البائع",
    rating: 5,
    reviewCount: 0,
    discountPercent:
      compareAtPrice && compareAtPrice > input.price
        ? Math.round((1 - input.price / compareAtPrice) * 100)
        : undefined,
    sellerProfitPercent: input.sellerProfitPercent ?? 10,
    isFeatured: false,
  };
}

const router: IRouter = Router();

router.get("/products", (req, res) => {
  const query = ListProductsQueryParams.parse(req.query);
  let result = [...products];

  if (query.search) {
    const search = query.search.toLocaleLowerCase("ar");
    result = result.filter((product) =>
      [product.title, product.description, product.brand]
        .join(" ")
        .toLocaleLowerCase("ar")
        .includes(search),
    );
  }
  if (query.category) {
    result = result.filter((product) => product.category === query.category);
  }
  if (query.brand) {
    result = result.filter((product) => product.brand === query.brand);
  }
  if (typeof query.maxPrice === "number") {
    result = result.filter((product) => product.price <= query.maxPrice!);
  }
  if (query.sort === "price_asc") {
    result.sort((a, b) => a.price - b.price);
  } else if (query.sort === "price_desc") {
    result.sort((a, b) => b.price - a.price);
  } else if (query.sort === "newest") {
    result.sort((a, b) => b.id - a.id);
  } else {
    result.sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured));
  }

  res.json(ListProductsResponse.parse(result));
});

router.post("/products", (req, res) => {
  const input = CreateProductBody.parse(req.body);
  const product = makeProduct({ id: Math.max(...products.map((item) => item.id)) + 1, ...input });
  products.unshift(product);
  res.status(201).json(product);
});

router.get("/products/:id", (req, res) => {
  const { id } = GetProductParams.parse(req.params);
  const product = products.find((item) => item.id === id);
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.json(GetProductResponse.parse(product));
});

router.patch("/products/:id", (req, res) => {
  const { id } = UpdateProductParams.parse(req.params);
  const product = products.find((item) => item.id === id);
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  const input = UpdateProductBody.parse(req.body);
  Object.assign(product, input);
  if (input.compareAtPrice !== undefined) {
    product.discountPercent =
      product.compareAtPrice && product.compareAtPrice > product.price
        ? Math.round((1 - product.price / product.compareAtPrice) * 100)
        : undefined;
  }
  res.json(product);
});

router.get("/categories", (_req, res) => {
  res.json(ListCategoriesResponse.parse(categories));
});

router.get("/cart", (_req, res) => {
  res.json(GetCartResponse.parse(calculateCart()));
});

router.post("/cart", (req, res) => {
  const input = AddCartItemBody.parse(req.body);
  const product = products.find((item) => item.id === input.productId);
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  cart.set(input.productId, Math.min(product.stock, (cart.get(input.productId) ?? 0) + input.quantity));
  res.json(calculateCart());
});

router.delete("/cart/:productId", (req, res) => {
  const { productId } = RemoveCartItemParams.parse(req.params);
  cart.delete(productId);
  res.json(calculateCart());
});

router.post("/cart/coupon", (req, res) => {
  const { code } = ApplyCouponBody.parse(req.body);
  const normalized = code.trim().toUpperCase();
  if (!["HH10", "WELCOME", "FREESHIP"].includes(normalized)) {
    res.status(400).json({ error: "الكود غير صالح أو انتهت صلاحيته" });
    return;
  }
  appliedCoupon = normalized;
  res.json(ApplyCouponResponse.parse(calculateCart()));
});

router.get("/customer/profile", (_req, res) => {
  res.json(
    GetCustomerProfileResponse.parse({
      name: "حامد",
      walletBalance,
      loyaltyPoints,
      addresses: customerAddresses,
    }),
  );
});

router.post("/customer/addresses", (req, res) => {
  const input = CreateCustomerAddressBody.parse(req.body);
  const address = {
    id: Math.max(0, ...customerAddresses.map((item) => item.id)) + 1,
    label: input.label,
    address: input.address,
    isDefault: customerAddresses.length === 0,
  };
  customerAddresses.push(address);
  res.status(201).json(CreateCustomerAddressResponse.parse(address));
});

router.get("/orders", (_req, res) => {
  res.json(ListOrdersResponse.parse(orders));
});

router.post("/orders", (req, res) => {
  const input = CreateOrderBody.parse(req.body);
  const currentCart = calculateCart();
  if (currentCart.items.length === 0) {
    res.status(400).json({ error: "Cart is empty" });
    return;
  }
  const order: Order = {
    id: `HH-${Math.floor(2000 + Math.random() * 7000)}`,
    status: input.paymentMethod === "cash_on_delivery" ? "preparing" : "paid",
    createdAt: new Date().toISOString(),
    total: currentCart.total,
    paymentMethod: input.paymentMethod,
    itemCount: currentCart.items.reduce((sum, item) => sum + item.quantity, 0),
  };
  deliveryMeta.set(
    order.id,
    newDeliveryMeta({
      address: input.address,
      deliveryPartnerId: input.deliveryPartnerId ?? 1,
      sellerCount: new Set(currentCart.items.map((item) => item.product.sellerName)).size,
    }),
  );
  orders.unshift(order);
  cart.clear();
  res.status(201).json(order);
});

router.get("/orders/:id/tracking", (req, res) => {
  const { id } = GetOrderTrackingParams.parse(req.params);
  const order = orders.find((item) => item.id === id);
  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }
  res.json(GetOrderTrackingResponse.parse(buildTracking(order)));
});

router.post("/orders/:id/otp", (req, res) => {
  const { id } = RequestDeliveryOtpParams.parse(req.params);
  const order = orders.find((item) => item.id === id);
  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }
  const meta = getDeliveryMeta(order);
  meta.otp = String(Math.floor(100000 + Math.random() * 900000));
  meta.otpExpiresAt = Date.now() + 8 * 60 * 1000;
  res.json(
    RequestDeliveryOtpResponse.parse({
      sentTo: "+962 7 •••• 3488",
      expiresAt: new Date(meta.otpExpiresAt).toISOString(),
      codeHint: `ينتهي بـ ${meta.otp.slice(-2)}`,
      // This is exposed only to make the in-memory demo testable until SMS is connected.
      demoCode: meta.otp,
    }),
  );
});

router.post("/orders/:id/confirm-delivery", (req, res) => {
  const { id } = ConfirmDeliveryParams.parse(req.params);
  const { code } = ConfirmDeliveryBody.parse(req.body);
  const order = orders.find((item) => item.id === id);
  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }
  const meta = getDeliveryMeta(order);
  if (meta.otpVerified || (code === meta.otp && Date.now() <= meta.otpExpiresAt)) {
    meta.otpVerified = true;
    order.status = "delivered";
    res.json(ConfirmDeliveryResponse.parse(order));
    return;
  }
  res.status(400).json({ error: "رمز الاستلام غير صحيح أو انتهت صلاحيته" });
});

router.get("/reports/summary", (_req, res) => {
  const grossSales = Number(
    orders
      .filter((order) => order.status !== "cancelled")
      .reduce((sum, order) => sum + order.total, 0)
      .toFixed(2),
  );
  const adminCommission = Number((grossSales * ADMIN_COMMISSION_RATE).toFixed(2));
  res.json(
    GetReportSummaryResponse.parse({
      grossSales,
      adminCommission,
      sellerPayouts: Number((grossSales - adminCommission).toFixed(2)),
      orders: orders.length,
      productCount: products.length,
      trend: [
        { label: "أيلول 18", sales: 420 },
        { label: "أيلول 19", sales: 610 },
        { label: "أيلول 20", sales: 540 },
        { label: "أيلول 21", sales: 790 },
        { label: "أيلول 22", sales: 685 },
        { label: "أيلول 23", sales: 920 },
        { label: "أيلول 24", sales: grossSales || 860 },
      ],
    }),
  );
});

router.get("/auth/session", (_req, res) => {
  res.json(
    GetSessionResponse.parse({
      authenticated: true,
      role: "customer",
      name: "حامد",
    }),
  );
});

export default router;